import dotenv from "dotenv";
dotenv.config({
        path: '../../.env'
});
import { Redis } from "ioredis"

export const redisConnection = new Redis(process.env.VALKEY_URL,{
        maxRetriesPerRequest: null,
        port: 6379
});